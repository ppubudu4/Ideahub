-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 14, 2018 at 07:33 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dea`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `contactno` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`, `name`, `email`, `contactno`) VALUES
('achintha', '123', 'achinthad', '123', '123'),
('akila', '123', 'akilabada', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `dates`
--

CREATE TABLE `dates` (
  `dates` varchar(50) NOT NULL,
  `event_ID` int(11) NOT NULL,
  `events` varchar(50) NOT NULL,
  `cam_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dates`
--

INSERT INTO `dates` (`dates`, `event_ID`, `events`, `cam_name`) VALUES
('2018-02-12', 1, 'wwww', 'ssssss');

-- --------------------------------------------------------

--
-- Table structure for table `events_image`
--

CREATE TABLE `events_image` (
  `ID` int(11) NOT NULL,
  `event_ID` int(11) NOT NULL,
  `comment` varchar(50) NOT NULL,
  `photo` mediumblob NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event_comment`
--

CREATE TABLE `event_comment` (
  `event_ID` varchar(50) NOT NULL,
  `NIC` varchar(50) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `industry`
--

CREATE TABLE `industry` (
  `name` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `industry`
--

INSERT INTO `industry` (`name`, `password`, `email`) VALUES
('omobio', '123', '123'),
('sliit', '1234', 'san@sank.lk'),
('sanka', '1234', 'sankalpa@smartvalley.lk');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `NIC` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `degree` varchar(20) NOT NULL,
  `university` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contactno` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`username`, `password`, `NIC`, `name`, `degree`, `university`, `email`, `contactno`) VALUES
('achintha', '1234', '970343547V', 'achintha', 'UCD CS', '', 'dilesha@gmail.com', '0778854986'),
('123', '123', '123', '1234', '123', '', '123', '123'),
('789', '789', '789', '7891', '789', '789', '789', '789'),
('akilabada', '123', '123', 'akila', 'SE', 'plymouth bada', '123bada', '123'),
('sankalpa', '1234', '12345', 'sana', 'CS', 'NSBM', 'sankalpa@smartvalley.lk', '0771500164');

-- --------------------------------------------------------

--
-- Table structure for table `university`
--

CREATE TABLE `university` (
  `name` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contactno` varchar(10) NOT NULL,
  `location` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `university`
--

INSERT INTO `university` (`name`, `password`, `email`, `contactno`, `location`) VALUES
('NSBM', '123', '123', '123456', 'Homagama'),
('sliit', '123', '123', '123', 'malabe'),
('IIT', '123', 'sankalpa@smartvalley.lk', '0771500164', 'Hanthana'),
('IIT3', '321', 'sankalpa@smartvalley.lk', '0771500164', 'Hanthana');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dates`
--
ALTER TABLE `dates`
  ADD PRIMARY KEY (`event_ID`);

--
-- Indexes for table `events_image`
--
ALTER TABLE `events_image`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `event_comment`
--
ALTER TABLE `event_comment`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dates`
--
ALTER TABLE `dates`
  MODIFY `event_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events_image`
--
ALTER TABLE `events_image`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `event_comment`
--
ALTER TABLE `event_comment`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
